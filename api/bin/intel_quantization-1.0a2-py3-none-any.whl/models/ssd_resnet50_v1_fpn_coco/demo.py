#
#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2019 Intel Corporation
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

import intel_quantization.graph_converter as convert
from util import split_shared_inputs

_INPUTS = ['image_tensor']
_OUTPUTS = ['detection_boxes', 'detection_scores', 'num_detections', 'detection_classes']

_IN_GRAPH = '/home/maozhoug/workspace/pretrained-models/ssd_resnet50_v1_fpn_shared_box_predictor_640x640_coco14_sync_2018_07_03/frozen_inference_graph.pb'
_DATA_LOC = '/home/maozhoug/workspace/dataset/coco-data/coco_val.record'
_TF_MODEL = '/home/maozhoug/workspace/source/models'


def ssd_mobilenet_callback_cmds():
    script = '/home/maozhoug/workspace/source/models/research/coco_int8.sh'
    return 'bash ' + script + ' {}' + ' {} {}'.format(_DATA_LOC, _TF_MODEL)


if __name__ == '__main__':
    c = convert.GraphConverter(split_shared_inputs(_IN_GRAPH, ops=['Conv2D', 'BiasAdd']),
                               None, _INPUTS, _OUTPUTS, excluded_ops=['ConcatV2'], per_channel=True)
    c.gen_calib_data_cmds = ssd_mobilenet_callback_cmds()
    c.convert()
