#
#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2019 Intel Corporation
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import intel_quantization.graph_converter as convert

_INPUTS = ['input']
_OUTPUTS = ['resnet_v1_101/predictions/Reshape_1']
_IN_GRAPH = '/home/yang5y/workspace/pretrained-models/resnet101/resnet101_fp32_pretrained_model.pb'


def resnet101_callback_cmds():
    script = '/home/yang5y/workspace/source/intel-models/benchmarks/launch_benchmark.py'
    flags = ' --mode inference \
    --precision int8 \
    --framework tensorflow \
    --in-graph {} \
    --accuracy-only \
    --data-location /lustre/dataset/tensorflow/imagenet \
    --model-name resnet101 \
    --batch-size 100'
    return 'python ' + script + flags


if __name__ == '__main__':
    c = convert.GraphConverter(_IN_GRAPH, None, _INPUTS, _OUTPUTS)
    c.gen_calib_data_cmds = resnet101_callback_cmds()
    c.convert()
