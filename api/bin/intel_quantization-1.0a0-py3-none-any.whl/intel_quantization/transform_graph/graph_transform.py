#  -*- coding: utf-8 -*-
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from tensorflow.python.platform import flags as flags_lib
from api.intel_quantization.transform_graph.freeze_max_min import freeze_max
from api.intel_quantization.transform_graph.freeze_max_min import freeze_min
from api.intel_quantization.transform_graph.freeze_max_min import freeze_requantization_range
from api.intel_quantization.transform_graph.fuse_quantized_conv_and_requantize import fuse_quantized_conv_and_requantize
from tensorflow.python.platform import gfile
from tensorflow.core.framework import graph_pb2

flags = flags_lib
FLAGS = flags.FLAGS

flags.DEFINE_string("input", "", """Path to the input graph.""")
flags.DEFINE_string("output", "", """Path to the output graph.""")
flags.DEFINE_string("max_min_log", "", """Path to the max_min_log.""")


if __name__ == '__main__':
    # print("FLAGS: {}".format(str(FLAGS)))
    input_graph_def = graph_pb2.GraphDef()
    with gfile.Open(FLAGS.input, 'rb') as f:
        input_graph_def.ParseFromString(f.read())

    if FLAGS.max_min_log != '':  # freeze unit test
        freeze_max_graph = freeze_max(input_graph_def, FLAGS.max_min_log)
        freeze_min_graph = freeze_min(freeze_max_graph, FLAGS.max_min_log)
        output_graph = freeze_requantization_range(freeze_min_graph, FLAGS.max_min_log)
    else:  # fuse unit test
        output_graph = fuse_quantized_conv_and_requantize(input_graph_def)

    f = gfile.GFile(FLAGS.output, "w")
    f.write(output_graph.SerializeToString())

    print ('Done')
