#
#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2019 Intel Corporation
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
#

import intel_quantization.graph_converter as convert

_INPUTS = ['input']
_OUTPUTS = ['MobilenetV1/Predictions/Reshape_1']

_IN_GRAPH = '/home/yang5y/workspace/pretrained-models/mobilenet_v1/mobilenet_v1_1.0_224_frozen.pb'


def mobilenet_v1_callback_cmds():
    script = '/home/yang5y/workspace/source/intel-models/models/image_recognition/tensorflow/mobilenet_v1/inference/int8/accuracy.py'
    flags = ' --batch_size 100' + \
            ' --input_graph {}' + \
            ' --data_location /lustre/dataset/tensorflow/imagenet' + \
            ' --num_inter_threads 2' + \
            ' --num_intra_threads 28'
    return 'python ' + script + flags


if __name__ == '__main__':
    c = convert.GraphConverter(_IN_GRAPH, None, _INPUTS, _OUTPUTS, per_channel=True)
    c.gen_calib_data_cmds = mobilenet_v1_callback_cmds()
    c.convert()
